#include <GL/glew.h>
namespace model{
	void makeModel();
	void makeUpperArm();
	void makeLowerArm();
	void makeTorso();
	void makeThigh();
	void makeLeg();
}