#include "model.hpp"
namespace model{
	void makeModel(){
		makeUpperArm();
		makeLowerArm();
		makeTorso();
		makeThigh();
		makeLeg();
	};
}